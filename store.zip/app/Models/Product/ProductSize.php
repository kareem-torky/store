<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class ProductSize extends Model
{
    //
}
