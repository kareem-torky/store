<?php 

return [


	'dashboard' 				=> ' لوحة التحكم  ',
	'menu' 	=> [
					'home'=>'  الرئيسية ',
					'all' => 'قائمة الطعام ',
					'branches' => ' فروعنا  ',
				],


	'language' => 'اللغة  ',
	'howToGetUs' => 'كيف تتواصل معنا  ',
	'office' => ' الادارة العامة    ',
	'search' => '  بحث     ',
	'price' => '  ريال      ',
	'readMore' => '  اقرأ المزيد      ',
 


	//  messages 
	
	'added_success'			=> ' تم الاضافة بنجاح ',
	'updated_success'		=> ' تم التعديل بنجاح ',
	'deleted_success'		=> ' تم الحذف بنجاح ',
	'sorted_success'		=> ' تم ترتيب البيانات ',
	'dataNotFound'		    => ' للاسف   , لا توجد بيانات  !',
	'activate_message' 		=> ' تم التفعيل بنجاح ',
	'deactivate_message' 	=> ' تم الغاء التفعيل بنجاح ',
	'orderSuccess' 			=> ' تم ارسال طلبك بنجاح وسيتم التوصل معك  ! ',
	'subscribeMessage' 		=> ' شكرا لاشتراكك فى قائمتنا البريدية  ',
	'message_success' 		=> ' تم  ارسال رسالتك بنجاح  ',
	'notFoundData'			=> ' للاسف  لا توجد بيانات  ',



	



];

