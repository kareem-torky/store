<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class Size extends Model
{
    protected $fillable = ['language_id', 'title', 'desc'];
}
