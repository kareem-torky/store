<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from d29u17ylf1ylz9.cloudfront.net/fashion-shoe-preview/fashion-shoe/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Apr 2019 13:27:37 GMT -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Home Page</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico in the root directory -->
		<link rel="apple-touch-icon" href="apple-touch-icon.png">
        <link rel="shortcut icon" type="image/x-icon" href="{{furl()}}/img/favicon.ico">
		
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700,900' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,300' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="{{furl()}}/css/bootstrap.min.css">
		<!-- animate css -->
        <link rel="stylesheet" href="{{furl()}}/css/animate.css">
        <!-- nivo slider CSS -->
		<link rel="stylesheet" href="{{furl()}}/lib/css/nivo-slider.css" type="text/css" />
		<link rel="stylesheet" href="{{furl()}}/lib/css/preview.css" type="text/css" media="screen" />
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="{{furl()}}/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="{{furl()}}/css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="{{furl()}}/css/owl.carousel.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="{{furl()}}/css/font-awesome.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="{{furl()}}/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="{{furl()}}/css/responsive.css">

        <link rel="stylesheet" href="{{furl()}}/seoera/toster/jquery.toast.min.css">
        <link rel="stylesheet" href="{{furl()}}/seoera/css/ltr.css">

		<!-- modernizr css -->
        <script src="{{furl()}}/js/vendor/modernizr-2.8.3.min.js"></script>

        @yield('style')