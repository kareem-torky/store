

        <div class="form-body row">


          <div class="col-sm-12">
            <div>
              <hr>
                <h3>@lang('site.orderData')</h3>
              <hr>
            </div>
          </div>

          <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionOrder_title" class="form-control input-circle-right count-text-meta-title"  value="{{ json_data($site_content,'sectionOrder_title') }}"  
                        > 
                    </div>
                </div>
           </div>


           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionOrder_phone" class="form-control input-circle-right count-text-meta-title"  value="{{ json_data($site_content,'sectionOrder_phone') }}"  
                        > 
                    </div>
                </div>
           </div>

           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionOrder_address" class="form-control input-circle-right count-text-meta-title"  value="{{ json_data($site_content,'sectionOrder_address') }}"  
                        > 
                    </div>
                </div>
           </div>

           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionOrder_email" class="form-control input-circle-right count-text-meta-title"  value="{{ json_data($site_content,'sectionOrder_email') }}"  
                        > 
                    </div>
                </div>
           </div>






		 



        </div>
















