<?php 



/**
 * 
 */
class BaseClass
{
	
	function __construct()
	{
		# code...
	}
}