@extends('admin.main')



@section('content')



<!-- BEGIN PAGE BAR -->
<div class="page-bar">


    <ul class="page-breadcrumb">

    </ul>

</div>
<!-- END PAGE BAR -->



<!-- BEGIN PAGE TITLE-->
<h1 class="page-title"> @lang('site.homePage')  </h1>
<!-- END PAGE TITLE-->



<!-- END PAGE HEADER-->
<div class="note note-info">
    <p>  </p>
</div>



@endsection



