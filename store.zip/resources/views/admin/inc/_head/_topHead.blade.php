<!-- BEGIN TOP NAVIGATION MENU -->
                    <div class="top-menu">
                        <ul class="nav navbar-nav pull-right">
                    
                            <li class="dropdown dropdown-user">
                                <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                    <img alt=""  class="img-circle" src="{{aurl()}}/global/img/149071.png" />
                                    <span class="username username-hide-on-mobile"> {{ adminAuth()->user()->name }} </span>
                                    <i class="fa fa-angle-down"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-default">
                                
                                
                                    <li class="divider"> </li>
                           
                                    <li>
                                        <a href="{{ route('admin.get.authadmin.logout') }}" title="logout">
                                            <i class="icon-key"></i> @lang('site.logout') </a>
                                    </li>
                                </ul>


                            </li>



                            {{--<li class="dropdown dropdown-user">--}}
                                {{--<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">--}}
                                    {{--<span class="username username-hide-on-mobile"> @lang('site.language') </span>--}}
                                    {{--<i class="fa fa-angle-down"></i>--}}
                                {{--</a>--}}
                                {{--<ul class="dropdown-menu dropdown-menu-default">--}}

                                    {{--@foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)--}}
                                    {{--<li>--}}
                                        {{--<a rel="alternate" hreflang="{{ $localeCode }}" href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">--}}
                                            {{--{{ $properties['native'] }}--}}
                                        {{--</a>--}}
                                    {{--</li>--}}
                                    {{--@endforeach--}}
                                   {{----}}
                                {{--</ul>--}}

                                {{----}}
                            {{--</li>--}}



                            <!-- END USER LOGIN DROPDOWN -->
                            <!-- BEGIN QUICK SIDEBAR TOGGLER -->
                            <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                            <li class="dropdown dropdown-quick-sidebar-toggler">
                                <a href="{{ route('admin.get.authadmin.logout') }}" class="dropdown-toggle" title="logout">
                                    <i class="icon-logout"></i>
                                </a>
                            </li>
                            <!-- END QUICK SIDEBAR TOGGLER -->
                        </ul>
                    </div>
                    <!-- END TOP NAVIGATION MENU -->
