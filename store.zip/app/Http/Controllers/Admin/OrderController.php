<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\OrderRequest;
use App\Http\Controllers\Controller;
use App\Models\Product\Order;
use App\Models\Product\OrderContent;

class OrderController extends Controller
{
    public function pendingIndex()
    {
        $data['orders'] = Order::select('id','name','code')
        ->where('status', 'pending')
    	->get();
    	return view('admin.order.pending.index')->with($data);
    }

    public function toShipping(Request $request)
    {
        if($request->ajax())
        {
            $order = Order::where('id', $request->id)->first();
            $order->status = 'shipping';
            $order->save();
            $message['success'] = trans('site.shipped_success');
            return response()->json($message);
        }
    }

    public function pendingShow($id)
    {
        $data['order'] = Order::where('id', $id)->first();
        $data['orderContents'] = OrderContent::select('product_id','quantity','status')
        ->where('order_id', $id)
    	->get();
    	return view('admin.order.pending.show')->with($data);
    }

    public function shippingIndex()
    {
        $data['orders'] = Order::select('id','name','code')
        ->where('status', 'shipping')
    	->get();
    	return view('admin.order.shipping.index')->with($data);
    }

    public function toAccept(Request $request)
    {
        if($request->ajax())
        {
            $order = Order::where('id', $request->id)->first();
            $order->status = 'accepted';
            $order->save();
            $message['success'] = trans('site.accepted_success');
            return response()->json($message);
        }
    }


    public function toRefuse(Request $request)
    {
        if($request->ajax())
        {
            $order = Order::where('id', $request->id)->first();
            $order->status = 'refused';
            $order->save();
            $message['success'] = trans('site.refused_success');
            return response()->json($message);
        }
    }

}
