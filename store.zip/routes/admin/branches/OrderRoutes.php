<?php 

//  Size routes
//  
Route::group(['prefix'=>'order'],function()
{
	
  // show all data an data table 
  
  Route::group(['prefix'=>'pending'],function(){

		Route::get('/all','OrderController@pendingIndex')->name('get.order.pending.index');
		

    
    Route::post('/store','OrderController@pendingStore')->name('post.order.pending.store'); 
    


    // view data of specific item  
	  Route::get('/show/{id}','OrderController@pendingShow')->name('get.order.pending.show'); 

    // delete multi  item
	  Route::post('/delete/multi','OrderController@pendingDeleteMulti')->name('post.order.pending.deleteMulti'); 

		Route::post('/to-shipping','OrderController@toShipping')->name('post.order.pending.toShipping'); 

  });


  Route::group(['prefix'=>'shipping'],function(){

		Route::get('/all','OrderController@shippingIndex')->name('get.order.shipping.index');
		
		Route::post('/to-accept','OrderController@toAccept')->name('post.order.shipping.toAccept'); 

		Route::post('/to-refuse','OrderController@toRefuse')->name('post.order.shipping.toRefuse'); 

    
    // Route::post('/store','OrderController@pendingStore')->name('post.order.pending.store'); 
    
	  // Route::post('/toshipping/{id}','OrderController@pendingToShipping')->name('post.order.pending.toShipping'); 


    // // view data of specific item  
	  // Route::get('/show/{id}','OrderController@pendingShow')->name('get.order.pending.show'); 

    // // delete multi  item
	  // Route::post('/delete/multi','OrderController@pendingDeleteMulti')->name('post.order.pending.deleteMulti'); 

  });
  
  
	// // update data of specific item 
	// Route::put('/update','SizeController@update')->name('put.size.update'); 
	// // delete data of specific item
	// Route::get('/delete/{id}','SizeController@delete')->name('get.size.delete'); 
	// // delete multi  item
	// Route::post('/delete/multi','SizeController@deleteMulti')->name('post.size.deleteMulti'); 

	// // sort elements
	// Route::post('/sort','SizeController@sort')->name('post.size.sort'); 
	// // make this item visibile or not  
	// Route::get('/visibility/{id}','SizeController@visibility')->name('get.size.visibility'); 

});