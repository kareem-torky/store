@include('front.inc._linksHeader')
@include('front.inc._header')
@include('front.inc._nav')

@yield('content')

@include('front.inc._footer')
@include('front.inc._linksFooter')