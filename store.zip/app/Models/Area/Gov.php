<?php

namespace App\Models\Area;

use Illuminate\Database\Eloquent\Model;

class Gov extends Model
{
    protected $fillable = ['language_id', 'name', 'desc'];
}
