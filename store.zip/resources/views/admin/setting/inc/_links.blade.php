

        <div class="form-body row">


          <div class="col-sm-12">
            <div>
              <hr>
                <h3>@lang('site.linksData')</h3>
              <hr>
            </div>
          </div>

          <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionLinks_home" 
                        class="form-control input-circle-right count-text-meta-title"  
                        value="{{ json_data($site_content,'sectionLinks_home') }}"  
                        > 
                    </div>
                </div>
           </div>


           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionLinks_about" 
                        class="form-control input-circle-right count-text-meta-title"  
                        value="{{ json_data($site_content,'sectionLinks_about') }}"  
                        > 
                    </div>
                </div>
           </div>

           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionLinks_services" 
                        class="form-control input-circle-right count-text-meta-title"  
                        value="{{ json_data($site_content,'sectionLinks_services') }}"  
                        > 
                    </div>
                </div>
           </div>

          



           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionLinks_gallery" 
                        class="form-control input-circle-right count-text-meta-title"  
                        value="{{ json_data($site_content,'sectionLinks_gallery') }}"  
                        > 
                    </div>
                </div>
           </div>




           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionLinks_blog" 
                        class="form-control input-circle-right count-text-meta-title"  
                        value="{{ json_data($site_content,'sectionLinks_blog') }}"  
                        > 
                    </div>
                </div>
           </div>


           
           <div class="col-sm-12">
               <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon input-circle-left">
                            <i class="fa fa-text-width"></i>
                        </span>
                        <input type="text" name="sectionLinks_contactUs" 
                        class="form-control input-circle-right count-text-meta-title"  
                        value="{{ json_data($site_content,'sectionLinks_contactUs') }}"  
                        > 
                    </div>
                </div>
           </div>










		 



        </div>
















