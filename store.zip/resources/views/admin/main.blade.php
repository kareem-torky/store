@include('admin.inc._header')
@include('admin.inc._sidebar')

<!-- content of pages  -->

	@yield('content')

<!-- endcontent of pages  -->


@include('admin.inc._footer')